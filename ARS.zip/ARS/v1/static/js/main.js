// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    
    // Toggle all checkboxes in the generate reports form
    const selectAllCheckbox = document.getElementById('select-all-students');
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.student-checkbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = selectAllCheckbox.checked;
            });
        });
    }
    
    // File upload preview
    const fileInput = document.getElementById('file-upload');
    const fileLabel = document.querySelector('.custom-file-label');
    
    if (fileInput && fileLabel) {
        fileInput.addEventListener('change', function() {
            if (fileInput.files.length > 0) {
                fileLabel.textContent = fileInput.files[0].name;
            } else {
                fileLabel.textContent = 'Choose file...';
            }
        });
    }
    
    // Schedule form dynamic fields
    const frequencySelect = document.getElementById('frequency');
    const dayOfWeekField = document.getElementById('day-of-week-field');
    const dayOfMonthField = document.getElementById('day-of-month-field');
    
    if (frequencySelect) {
        frequencySelect.addEventListener('change', function() {
            if (frequencySelect.value === 'weekly') {
                dayOfWeekField.style.display = 'block';
                dayOfMonthField.style.display = 'none';
            } else if (frequencySelect.value === 'monthly') {
                dayOfWeekField.style.display = 'none';
                dayOfMonthField.style.display = 'block';
            } else {
                dayOfWeekField.style.display = 'none';
                dayOfMonthField.style.display = 'none';
            }
        });
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-hide flash messages after 5 seconds
    const flashMessages = document.querySelectorAll('.alert');
    flashMessages.forEach(message => {
        setTimeout(() => {
            message.style.opacity = '0';
            setTimeout(() => {
                message.style.display = 'none';
            }, 500);
        }, 5000);
    });
});
