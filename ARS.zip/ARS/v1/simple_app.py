# simple_app.py
from flask import Flask
import pymysql
from flask_sqlalchemy import SQLAlchemy
import os
from sqlalchemy import text  # Add this import

# Register PyMySQL as the MySQL driver
pymysql.install_as_MySQLdb()

app = Flask(__name__)

# Database configuration from environment variables or hardcoded for testing
db_user = os.environ.get('DB_USER', 'root')
db_password = os.environ.get('DB_PASSWORD', 'nareen')
db_host = os.environ.get('DB_HOST', 'localhost')
db_name = os.environ.get('DB_NAME', 'reporting_system')

# Configure SQLAlchemy - BEFORE handling any requests
app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql://{db_user}:{db_password}@{db_host}/{db_name}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize SQLAlchemy with the app
db = SQLAlchemy(app)

@app.route('/')
def index():
    return "Hello, World! The application is running."

@app.route('/test-db')
def test_db():
    try:
        # Use text() to explicitly declare the SQL as text
        result = db.session.execute(text('SELECT 1')).fetchone()
        if result:
            return 'Database connection successful!'
        else:
            return 'Unknown database error'
    except Exception as e:
        return f'Database connection failed: {str(e)}'

if __name__ == '__main__':
    app.run(debug=True, port=5000)
