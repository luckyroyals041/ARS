# scheduler.py
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
import logging
from flask import current_app

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class ReportScheduler:
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.jobs = {}
    
    def start(self):
        """Start the scheduler"""
        if not self.scheduler.running:
            self.scheduler.start()
            logger.info("Scheduler started")
    
    def shutdown(self):
        """Shutdown the scheduler"""
        if self.scheduler.running:
            self.scheduler.shutdown()
            logger.info("Scheduler shutdown")
    
    def add_report_job(self, job_id, func, frequency, **kwargs):
        """Add a new scheduled job"""
        # Remove existing job with same ID if it exists
        if job_id in self.jobs:
            self.remove_job(job_id)
        
        # Create appropriate trigger based on frequency
        if frequency == 'daily':
            trigger = CronTrigger(
                hour=kwargs.get('hour', 0),
                minute=kwargs.get('minute', 0)
            )
        elif frequency == 'weekly':
            trigger = CronTrigger(
                day_of_week=kwargs.get('day_of_week', 0),  # Monday is 0
                hour=kwargs.get('hour', 0),
                minute=kwargs.get('minute', 0)
            )
        elif frequency == 'monthly':
            trigger = CronTrigger(
                day=kwargs.get('day', 1),  # First day of month
                hour=kwargs.get('hour', 0),
                minute=kwargs.get('minute', 0)
            )
        else:
            raise ValueError(f"Unsupported frequency: {frequency}")
        
        # Add the job to the scheduler
        job = self.scheduler.add_job(
            func,
            trigger=trigger,
            id=job_id,
            replace_existing=True
        )
        
        self.jobs[job_id] = job
        logger.info(f"Added {frequency} job with ID: {job_id}")
        
        return job
    
    def remove_job(self, job_id):
        """Remove a scheduled job"""
        if job_id in self.jobs:
            self.scheduler.remove_job(job_id)
            del self.jobs[job_id]
            logger.info(f"Removed job with ID: {job_id}")
            return True
        return False
    
    def get_jobs(self):
        """Get all scheduled jobs"""
        return self.jobs
