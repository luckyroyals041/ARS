# report_generator.py
from flask import current_app, render_template_string
import pandas as pd
import os
from datetime import datetime
import logging
from sqlalchemy import text
from models import db, Student, Course, Grade, Report

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def calculate_sgpa(student_id, semester):
    """Calculate SGPA for a student in a specific semester"""
    from models import db, Grade, Course
    import logging
    
    logger = logging.getLogger(__name__)
    
    # Get all grades for the student in the specified semester
    grades = Grade.query.join(Course).filter(
        Grade.student_id == student_id,
        Course.semester == semester
    ).all()
    
    if not grades:
        logger.warning(f"No grades found for student ID {student_id} in semester {semester}")
        return 0.0
    
    total_credits = 0
    weighted_points = 0
    
    logger.info(f"Calculating SGPA for student ID {student_id} in semester {semester}")
    logger.info(f"Found {len(grades)} grade records")
    
    for grade in grades:
        # Get the course associated with this grade
        course = grade.course
        
        logger.debug(f"Course: {course.name}, Credits: {course.credits}, Grade Points: {grade.grade_points}")
        
        # Add the course credits to total
        total_credits += course.credits
        
        # Add the weighted grade points (grade points * credits)
        weighted_points += grade.grade_points * course.credits
    
    logger.info(f"Total credits: {total_credits}, Total weighted points: {weighted_points}")
    
    # Calculate SGPA
    if total_credits > 0:
        sgpa = weighted_points / total_credits
        logger.info(f"Calculated SGPA: {sgpa}")
        return sgpa
    
    logger.warning("Total credits is zero, returning SGPA as 0.0")
    return 0.0

def calculate_cgpa(student_id):
    """Calculate CGPA for a student across all semesters"""
    from models import db, Grade, Course
    import logging
    
    logger = logging.getLogger(__name__)
    
    # Get all grades for the student with their associated courses
    all_grades = Grade.query.join(Course).filter(Grade.student_id == student_id).all()
    
    if not all_grades:
        logger.warning(f"No grades found for student ID {student_id}")
        return 0.0
    
    total_credits = 0
    weighted_points = 0
    
    logger.info(f"Calculating CGPA for student ID {student_id}")
    logger.info(f"Found {len(all_grades)} grade records")
    
    for grade in all_grades:
        # Get the course associated with this grade
        course = grade.course
        
        logger.debug(f"Course: {course.name}, Credits: {course.credits}, Grade Points: {grade.grade_points}")
        
        # Add the course credits to total
        total_credits += course.credits
        
        # Add the weighted grade points (grade points * credits)
        weighted_points += grade.grade_points * course.credits
    
    logger.info(f"Total credits: {total_credits}, Total weighted points: {weighted_points}")
    
    # Calculate CGPA
    if total_credits > 0:
        cgpa = weighted_points / total_credits
        logger.info(f"Calculated CGPA: {cgpa}")
        return cgpa
    
    logger.warning("Total credits is zero, returning CGPA as 0.0")
    return 0.0

def generate_student_report(student_id):
    """Generate a report for a single student"""
    # Ensure we're in an application context
    with current_app.app_context():
        student = Student.query.get(student_id)
        if not student:
            logger.error(f"Student with ID {student_id} not found")
            return None
            
        # Get all semesters for this student
        # Use text() for raw SQL queries
        semesters_query = text("""
            SELECT DISTINCT c.semester 
            FROM course c 
            JOIN grade g ON g.course_id = c.id 
            WHERE g.student_id = :student_id 
            ORDER BY c.semester
        """)
        semesters = db.session.execute(semesters_query, {"student_id": student_id}).fetchall()
        
        semester_data = []
        for sem in semesters:
            semester = sem[0]
            courses = Course.query.join(Grade).filter(
                Grade.student_id == student_id,
                Course.semester == semester
            ).all()
            
            course_data = []
            failed_count = 0
            for course in courses:
                grade = Grade.query.filter_by(
                    student_id=student_id,
                    course_id=course.id
                ).first()
                
                if grade.result.lower() == 'fail':
                    failed_count += 1
                    
                course_data.append({
                    'name': course.name,
                    'code': course.code,
                    'credits': course.credits,
                    'grade': grade.grade,
                    'grade_points': grade.grade_points,
                    'credits_obtained': grade.credits_obtained,
                    'result': grade.result,
                    'month_year': grade.month_year
                })
            
            sgpa = calculate_sgpa(student_id, semester)
            semester_data.append({
                'semester': semester,
                'courses': course_data,
                'total_subjects': len(courses),
                'failed_subjects': failed_count,
                'sgpa': sgpa
            })
        
        cgpa = calculate_cgpa(student_id)
        
        # Get university information from config
        university_name = current_app.config.get('UNIVERSITY_NAME', 'Aditya University')
        university_logo = current_app.config.get('UNIVERSITY_LOGO', '/static/img/logo.png')
        contact_info = current_app.config.get('UNIVERSITY_CONTACT', 'University Contact Information')
        
        # Prepare report data
        report_data = {
            'student': {
                'name': student.name,
                'reg_number': student.reg_number,
                'branch': student.branch,
                'semester': student.semester
            },
            'semesters': semester_data,
            'cgpa': cgpa,
            'university_name': university_name,
            'university_logo': university_logo,
            'contact_info': contact_info,
            'additional_notes': 'This report was automatically generated by the Automated Reporting System.',
            'generation_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # Generate HTML report using Flask's render_template_string
        with open('templates/report_template.html', 'r') as f:
            template_content = f.read()
        
        html_report = render_template_string(template_content, **report_data)
        
        # Save the report
        report_dir = os.path.join(current_app.static_folder, 'reports')
        os.makedirs(report_dir, exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        filename = f"{student.reg_number}_{timestamp}_report.html"
        report_path = os.path.join(report_dir, filename)
        
        with open(report_path, 'w') as f:
            f.write(html_report)
        
        logger.info(f"Generated report for student {student.name} at {report_path}")
        return report_path

def generate_all_reports():
    """Generate reports for all students"""
    # Ensure we're in an application context
    with current_app.app_context():
        students = Student.query.all()
        report_paths = []
        
        for student in students:
            report_path = generate_student_report(student.id)
            if report_path:
                # Extract just the filename from the path
                filename = os.path.basename(report_path)
                
                # Save report record in database
                report = Report(
                    student_id=student.id,
                    filename=filename
                )
                db.session.add(report)
                report_paths.append(report_path)
        
        db.session.commit()
        logger.info(f"Generated {len(report_paths)} reports")
        return report_paths
