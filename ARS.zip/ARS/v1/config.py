import os

# Flask configuration
SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-key-for-development-only')
DEBUG = os.environ.get('FLASK_DEBUG', 'True') == 'True'

# File upload configuration
UPLOAD_FOLDER = 'uploads'
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload size

# Database configuration
DB_USER = os.environ.get('DB_USER', 'root')
DB_PASSWORD = os.environ.get('DB_PASSWORD', '')
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_PORT = os.environ.get('DB_PORT', '3306')
DB_NAME = os.environ.get('DB_NAME', 'reporting_system')

# MySQL connection string
SQLALCHEMY_DATABASE_URI = f'mysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}'
SQLALCHEMY_TRACK_MODIFICATIONS = False
SQLALCHEMY_ENGINE_OPTIONS = {
    'pool_recycle': 280,
    'pool_timeout': 20,
    'pool_size': 10,
    'max_overflow': 5
}

# University information
UNIVERSITY_NAME = "Your University Name"
UNIVERSITY_LOGO = "img/logo.png"
UNIVERSITY_CONTACT = "123 University Avenue, City, Country | Phone: +1-234-567-8900 | Email: info@university.edu"
