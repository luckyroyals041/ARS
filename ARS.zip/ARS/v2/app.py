# app.py
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from werkzeug.utils import secure_filename
import pandas as pd
import os
import pymysql
from datetime import datetime
from sqlalchemy import text
import logging
from models import db, Student, Course, Grade, Report
import report_generator
from scheduler import ReportScheduler

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Register PyMySQL as the MySQL driver
pymysql.install_as_MySQLdb()

app = Flask(__name__)

# Load configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-key-for-development-only')
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size

@app.context_processor
def inject_now():
    return {'now': datetime.now()}

# Database configuration from environment variables
db_user = os.environ.get('DB_USER', 'root')
db_password = os.environ.get('DB_PASSWORD', 'nareen')
db_host = os.environ.get('DB_HOST', 'localhost')
db_port = os.environ.get('DB_PORT', '3306')
db_name = os.environ.get('DB_NAME', 'reporting_system')

# MySQL connection string
app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    'pool_recycle': 280,
    'pool_timeout': 20,
    'pool_size': 10,
    'max_overflow': 5
}

# University information
app.config['UNIVERSITY_NAME'] = "Aditya University"
app.config['UNIVERSITY_LOGO'] = "static/img/logo.png"
app.config['UNIVERSITY_CONTACT'] = "Aditya Nagar, ADB Road, Surampalem - Pin:533437 Kakinada District, Andhra Pradesh, INDIA | Phone: +91 9989 776661 | Email: info@adityauniversity.in"

# Initialize database with the app
db.init_app(app)

# Initialize scheduler
from scheduler import ReportScheduler
scheduler = ReportScheduler()

# Import report generator after models are defined
import report_generator

# Routes
@app.route('/')
def index():
    student_count = Student.query.count()
    course_count = Course.query.count()
    report_count = Report.query.count()
    
    recent_reports = Report.query.order_by(Report.generated_at.desc()).limit(5).all()
    
    return render_template('index.html', 
                          student_count=student_count,
                          course_count=course_count,
                          report_count=report_count,
                          recent_reports=recent_reports,
                          now=datetime.now())

@app.route('/upload', methods=['GET', 'POST'])
def upload_data():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
            
        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Process the uploaded file
            try:
                data_type = request.form.get('data_type')
                process_data_file(filepath, data_type)
                flash('Data uploaded and processed successfully!')
            except Exception as e:
                flash(f'Error processing file: {str(e)}')
                
            return redirect(url_for('index'))
            
    return render_template('upload.html')

@app.route('/generate-reports', methods=['GET', 'POST'])
def generate_reports():
    students = Student.query.all()
    
    # Get pre-selected student from query parameter
    preselected_student = request.args.get('student')
    
    if request.method == 'POST':
        selected_students = request.form.getlist('students')
        
        if not selected_students:
            flash('Please select at least one student')
            return redirect(request.url)
            
        # Generate reports for selected students
        generated_reports = []
        for student_id in selected_students:
            report_path = report_generator.generate_student_report(int(student_id))
            if report_path:
                # Extract just the filename from the path
                filename = os.path.basename(report_path)
                
                # Save report record in database
                report = Report(
                    student_id=int(student_id),
                    filename=filename
                )
                db.session.add(report)
                generated_reports.append(report)
                
        db.session.commit()
        flash(f'Successfully generated {len(generated_reports)} reports!')
        return redirect(url_for('reports'))
        
    return render_template('generate.html', students=students, preselected_student=preselected_student)


@app.route('/schedule', methods=['GET', 'POST'])
def schedule():  # Changed from schedule_reports to schedule
    if request.method == 'POST':
        frequency = request.form.get('frequency')
        
        if frequency == 'daily':
            hour = int(request.form.get('hour', 0))
            minute = int(request.form.get('minute', 0))
            scheduler.add_report_job(
                'daily_reports', 
                report_generator.generate_all_reports, 
                'daily', 
                hour=hour, 
                minute=minute
            )
        elif frequency == 'weekly':
            day = int(request.form.get('day', 0))
            hour = int(request.form.get('hour', 0))
            minute = int(request.form.get('minute', 0))
            scheduler.add_report_job(
                'weekly_reports', 
                report_generator.generate_all_reports, 
                'weekly', 
                day_of_week=day,
                hour=hour, 
                minute=minute
            )
        elif frequency == 'monthly':
            day = int(request.form.get('day', 1))
            hour = int(request.form.get('hour', 0))
            minute = int(request.form.get('minute', 0))
            scheduler.add_report_job(
                'monthly_reports', 
                report_generator.generate_all_reports, 
                'monthly', 
                day=day,
                hour=hour, 
                minute=minute
            )
            
        flash(f'Reports scheduled to run {frequency}')
        return redirect(url_for('index'))
        
    return render_template('schedule.html')

@app.route('/debug/student/<int:student_id>/grades')
def debug_student_grades(student_id):
    """Debug route to check student grade data"""
    if not app.debug:
        return "Debug routes only available in debug mode", 403
        
    student = Student.query.get_or_404(student_id)
    grades = Grade.query.join(Course).filter(Grade.student_id == student_id).all()
    
    grade_data = []
    for grade in grades:
        grade_data.append({
            'course_name': grade.course.name,
            'course_code': grade.course.code,
            'semester': grade.course.semester,
            'credits': grade.course.credits,
            'grade': grade.grade,
            'grade_points': grade.grade_points,
            'result': grade.result
        })
    
    return render_template('debug_grades.html', 
                          student=student, 
                          grades=grade_data,
                          cgpa=report_generator.calculate_cgpa(student_id))

@app.route('/students')
def list_students():
    """List all students"""
    students = Student.query.order_by(Student.name).all()
    return render_template('students.html', students=students)


@app.route('/reports')
def reports():
    all_reports = Report.query.order_by(Report.generated_at.desc()).all()
    return render_template('reports.html', reports=all_reports)

@app.route('/reports/<filename>')
def view_report(filename):
    return send_from_directory(os.path.join(app.static_folder, 'reports'), filename)

@app.route('/test-db')
def test_db():
    try:
        # Use text() to explicitly declare the SQL as text
        result = db.session.execute(text('SELECT 1')).fetchone()
        if result:
            return 'Database connection successful!'
        else:
            return 'Unknown database error'
    except Exception as e:
        return f'Database connection failed: {str(e)}'

def process_data_file(filepath, data_type):
    """Process uploaded data files based on their type"""
    if data_type == 'students':
        process_student_data(filepath)
    elif data_type == 'courses':
        process_course_data(filepath)
    elif data_type == 'grades':
        process_grade_data(filepath)
    else:
        raise ValueError(f"Unknown data type: {data_type}")

def process_student_data(filepath):
    """Process student data from CSV/Excel file"""
    df = pd.read_excel(filepath) if filepath.endswith('.xlsx') else pd.read_csv(filepath)
    
    for _, row in df.iterrows():
        # Check if student already exists
        existing_student = Student.query.filter_by(reg_number=row['reg_number']).first()
        
        if existing_student:
            # Update existing student
            existing_student.name = row['name']
            existing_student.branch = row['branch']
            existing_student.semester = row['semester']
        else:
            # Create new student
            student = Student(
                name=row['name'],
                reg_number=row['reg_number'],
                branch=row['branch'],
                semester=row['semester']
            )
            db.session.add(student)
    
    db.session.commit()

def process_course_data(filepath):
    """Process course data from CSV/Excel file"""
    df = pd.read_excel(filepath) if filepath.endswith('.xlsx') else pd.read_csv(filepath)
    
    for _, row in df.iterrows():
        # Check if course already exists
        existing_course = Course.query.filter_by(code=row['code']).first()
        
        if existing_course:
            # Update existing course
            existing_course.name = row['name']
            existing_course.credits = row['credits']
            existing_course.semester = row['semester']
        else:
            # Create new course
            course = Course(
                name=row['name'],
                code=row['code'],
                credits=row['credits'],
                semester=row['semester']
            )
            db.session.add(course)
    
    db.session.commit()

def process_grade_data(filepath):
    """Process grade data from CSV/Excel file"""
    df = pd.read_excel(filepath) if filepath.endswith('.xlsx') else pd.read_csv(filepath)
    
    for _, row in df.iterrows():
        # Get student and course
        student = Student.query.filter_by(reg_number=row['reg_number']).first()
        course = Course.query.filter_by(code=row['course_code']).first()
        
        if not student or not course:
            continue
        
        # Check if grade already exists
        existing_grade = Grade.query.filter_by(
            student_id=student.id,
            course_id=course.id
        ).first()
        
        if existing_grade:
            # Update existing grade
            existing_grade.grade = row['grade']
            existing_grade.grade_points = row['grade_points']
            existing_grade.credits_obtained = row['credits_obtained']
            existing_grade.result = row['result']
            existing_grade.month_year = row['month_year']
        else:
            # Create new grade
            grade = Grade(
                student_id=student.id,
                course_id=course.id,
                grade=row['grade'],
                grade_points=row['grade_points'],
                credits_obtained=row['credits_obtained'],
                result=row['result'],
                month_year=row['month_year']
            )
            db.session.add(grade)
    
    db.session.commit()

if __name__ == '__main__':
    # Create upload and reports directories if they don't exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(os.path.join(app.static_folder, 'reports'), exist_ok=True)
    
    with app.app_context():
        db.create_all()  # Create database tables
    
    scheduler.start()  # Start the scheduler
    app.run(debug=True,host='0.0.0.0', port=5000)